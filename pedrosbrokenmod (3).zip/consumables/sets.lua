SMODS.ConsumableType {
    key = 'new_set',
    primary_colour = HEX('666666'),
    secondary_colour = HEX('666666'),
    collection_rows = { 4, 5 },
    shop_rate = 10,
    cards = {},
    loc_txt = {
        name = "New Set",
        collection = "New Set Cards",
    }
}